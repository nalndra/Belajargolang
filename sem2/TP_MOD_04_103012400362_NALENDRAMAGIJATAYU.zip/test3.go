package main

import"fmt"

func main() {
    var choice int
    for {
        menu()
        fmt.Print("Pilih (1/2/3/4)? ")
        fmt.Scanln(&choice)

        switch choice {
        case 1:
            hitungJumlah()
        case 2:
            hitungKali()
        case 3:
            hitungBagi()
        case 4:
            fmt.Println("Terima Kasih.")
            return
        default:
            fmt.Println("Pilihan tidak valid. Silakan coba lagi.")
        }
    }
}

func menu() {
    fmt.Println("-----------------------")
    fmt.Println(" M E N U")
    fmt.Println("-----------------------")
    fmt.Println("1. Hitung Penjumlahan")
    fmt.Println("2. Hitung Perkalian")
    fmt.Println("3. Hitung Pembagian")
    fmt.Println("4. Exit")
    fmt.Println("-----------------------")
}

func hitungJumlah() {
    var a, b int
    fmt.Print("Masukkan dua bilangan yang akan dijumlahkan: ")
    fmt.Scanln(&a, &b)
    fmt.Printf("Hasil penjumlahan: %d\n", a + b)
}

func hitungKali() {
    var a, b int
    fmt.Print("Masukkan dua bilangan yang akan dikalikan: ")
    fmt.Scanln(&a, &b)
    fmt.Printf("Hasil perkalian: %d\n", a * b)
}

func hitungBagi() {
    var a, b float64
    fmt.Print("Masukkan dua bilangan yang akan dibagikan: ")
    fmt.Scanln(&a, &b)
    if b == 0 {
        fmt.Println("Tidak dapat membagi dengan nol.")
    } else {
        fmt.Printf("Hasil pembagian: %f\n", a / b)
    }
}
