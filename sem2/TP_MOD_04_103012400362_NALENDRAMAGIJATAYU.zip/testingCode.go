package main

import (
    "fmt"
    "math"
)

func hitungLuasKelilingLingkaran(r float64, l, k *float64) {
    *l = math.Pi * r * r 
    *k = 2 * math.Pi * r
}

func hitungLuasKelilingPersegi(s float64, l, k *float64) {
    *l = s * s
    *k = 4 * s
}

func hitungTotal(lL, lP, kL, kP float64, totalLuas, totalKeliling *float64) {
    *totalLuas = lL + lP
    *totalKeliling = kL + kP
}

func main() {
    var r, s, lL, lP, kL, kP, totalKeliling, totalLuas float64
    
    fmt.Printf("%-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s\n",
        "R", "S", "LL", "LP", "KL", "KP", "TL", "TP")

    for {
        fmt.Scan(&r, &s)
        if r == 0 && s == 0 {
            break
        }
        hitungLuasKelilingLingkaran(r, &lL, &kL)
        hitungLuasKelilingPersegi(s, &lP, &kP)
        hitungTotal(lL, lP, kL, kP, &totalLuas, &totalKeliling)
        
        fmt.Printf("%-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f\n", 
            r, s, lL, lP, kL, kP, totalLuas, totalKeliling)
    }
}
