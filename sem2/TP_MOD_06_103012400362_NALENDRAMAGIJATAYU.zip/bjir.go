package main
import "fmt"

func main() {
	var n int
	
	fmt.Scan(&n)
	cetakBaris(n)
}

func cetakBaris(n int) {
	if n%2 != 0 { 
		n--
	}
	fmt.Print(n)
	if n > 2 {
		fmt.Print(", ")
		cetakBaris(n - 2)
	}else{
		fmt.Println()
	}
}
