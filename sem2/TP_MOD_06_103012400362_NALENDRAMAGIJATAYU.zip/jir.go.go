package main

import "fmt"

const ukuranUbin = 30 * 30

func main() {
	var l, w, rA, tN int
	fmt.Scan(&l, &w)

	conversionToCm(&l, &w)
	rA = calRoom(l, w)
	tN = countTiles(rA)
	updateTiles(&tN, rA)

	fmt.Printf("You need: %d tiles\n", tN)
}

func conversionToCm(length, width *int) {
	*length *= 100
	*width *= 100
}

func countTiles(roomArea int) int {
	return roomArea / ukuranUbin
}

func calRoom(length, width int) int {
	return length * width
}

func isMore(roomArea int) bool {
	return roomArea%ukuranUbin != 0
}

func updateTiles(tilesNeeded *int, rA int) {
	if isMore(rA) {
		*tilesNeeded = *tilesNeeded + 1
	}
}
